#!/usr/bin/env python3

import os
import sys

if __name__ == "__main__":
    truth_dir = sys.argv[1]
    check_dir = sys.argv[2]

    matched, unmatched = 0, 0

    for dirpath, dirnames, filenames in os.walk(truth_dir):
        for filename in filenames:
            src = os.path.join(dirpath, filename)
            relpath = os.path.relpath(src, truth_dir)
            dest = os.path.join(check_dir, relpath)

            with open(src, 'rb') as f:
                src_data = f.read()
            with open(dest, 'rb') as f:
                dest_data = f.read()

            if src_data == dest_data:
                matched += 1
            else:
                unmatched +=1
                print("{} doesn't match".format(relpath))
                print("src length: {}; dest length: {}; diff: {}".format(len(src_data), len(dest_data), len(src_data)-len(dest_data)))
                # try:
                    # src_bson = bson.loads(src_data)
                # except Exception as ex:
                    # print(ex)
                    # print("unable to parse src")

                # try:
                    # dest_bson = bson.loads(dest_data)
                # except Exception as ex:
                    # print(ex)
                    # print("unable to parse dest")

                # print("src_bson: {}\ndest_bson: {}".format(src_bson, dest_bson))

    print('matched: {}; unmatched: {}'.format(matched, unmatched))
